package com.labs1904

object NextBiggestNumber {

  def main(args: Array[String]) = {

    val input = args(0).toInt
    val nextBiggestNumber = getNextBiggestNumber(input)
    println(s"Input: $input")
    println(s"Next biggest number: $nextBiggestNumber")
  }

  def getNextBiggestNumber(i: Integer) = {
    //TODO: Implement me!
    0
  }
}
