# Scala Next Biggest Number

The following project was created using Scala 2.11.2

## Creating the project in Intellij
`File -> New -> Project From Existing Sources -> <Browse to de-hours-with-experts/NextBiggestNumber/scala/pom.xml>`

## Building the project
From de-hours-with-experts/NextBiggestNumber/scala:

`mvn clean package`

## Running the tests
From de-hours-with-experts/NextBiggestNumber/scala:

`mvn test`


## Running the project
From de-hours-with-experts/NextBiggestNumber/scala:

`java -cp target/NextBiggestNumber-1.0-jar-with-dependencies.jar com.labs1904.NextBiggestNumber 123`

