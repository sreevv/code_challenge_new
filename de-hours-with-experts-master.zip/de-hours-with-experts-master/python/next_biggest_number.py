#!/usr/bin/python3
import sys

def main():
    next_biggest_number(sys.argv[1])


def next_biggest_number(num):
    #TODO: Implement me!
    return 0

if __name__ == "__main__":
    main()



