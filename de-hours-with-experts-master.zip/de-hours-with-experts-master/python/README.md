# Python NextBiggestNumber

## Testing the project 

From `de-hours-with-experts/NextBiggestNumber/python`:

`pytest`

## Running the project

From `de-hours-with-experts/NextBiggestNumber/python`:

`next_biggest_number.py 123`

